<?php

define('ARC2_DIR', __DIR__ . '/../');

require_once ARC2_DIR . 'ARC2.php';

class ARC2_TestCase extends PHPUnit_Framework_TestCase {

    public function __construct() {
		
    }
	
}
